module.exports = {
    useFileSystemPublicRoutes: false,
}